<footer class="footer bg-dark ">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script>
                &copy; PU-SDA JAWA TIMUR
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript:void(0);">About Us</a>
                    <a href="javascript:void(0);">Help</a>
                    <a href="javascript:void(0);">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\KULI AHH\MAGANG\Project PU-SDA\pusda-main (1)\pusda-main\Backend\resources\views/layouts/components/footer.blade.php ENDPATH**/ ?>