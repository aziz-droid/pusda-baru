<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

## ERD 
<h4><a href="https://dbdiagram.io/d/63439119f0018a1c5fc957a7" target="_blank">Entity Relationship Diagram</a></h4>

## TODO
- [x] Lorem Ipsum is simply dummy text of the printing and typesetting industry


## ON PROGRESS
- [x] API Export And Import
- [x] Change database relation from one to many to many
- [x] API Forgot Password


## DONE
- [x] Install Package UI V3
- [x] Install Package Auth Login base
- [x] Install Package Laratrust
- [x] Config Role and Sender
- [x] Migratation Database to mysql
- [x] Import Assets View
- [x] Manajement Component View Base
- [x] Base Login View
- [x] Base Layout View
- [x] Setup Dashboard view by role
- [x] Setup Dashboard controller by role
- [x] Creating Tables and Creating Relationships
- [x] Setup Controller Base
- [x] Setup Controller API/Admin
- [x] Setup Controller API/Users
- [x] Setup Documentasi API with Swegger 
- [x] CRUD  Rest API controller API
- [x] CRUD  Rest API controller API
- [x] API Auth
- [x] API CRUD Profile User
- [x] API CRUD UPT Parent and Clidern
